# Tank Nexus — Online Browser Multiplayer

HTML/CSS/JavaScript original game with a single-instance Node.js WebSocket room server. Deploy with the included Render Blueprint; no player installations, IP addresses, or terminals needed.

## Deploy via browser

Create a GitHub repository, upload `index.html`, `server.js`, `package.json`, and `render.yaml` at the repository root, then create a **Render Blueprint** connected to that repository. Render installs the dependencies and runs the server automatically. Render supplies the final HTTPS game URL; the browser connects over WSS on the same origin.

See [README_FA.md](README_FA.md) for Persian step-by-step instructions and limitations.

## Gameplay

Host: **START COMBAT → Multiplayer → mode → Create Room → COPY INVITE LINK**.
Guests: open invite link, enter name, press **Connect**. Host clicks **START MULTIPLAYER GAME**.

## Limitations

The Node.js server is authoritative for player movement and rooms; the original browser host still owns legacy enemies/world simulation. The host must stay connected. Rooms are in memory and a server restart clears them. Real WAN lag/ping and visual gameplay have not been end-to-end tested; this is not a production-grade fully server-authoritative engine. Render Free services may sleep and restart. Run one server instance for in-memory rooms.
